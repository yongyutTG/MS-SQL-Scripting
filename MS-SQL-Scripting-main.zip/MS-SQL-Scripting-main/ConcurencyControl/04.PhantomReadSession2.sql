﻿USE AdventureWorks;
GO

--Step 2
	INSERT Production.ProductCategory ([Name])
	VALUES ('Safety Gear')
--Step 3 ==> 04.PhantomReadSession1.sql

--Step 5
	INSERT Production.ProductCategory ([Name])
	VALUES ('Gifts, Goodies and More')

--Step 6 ==> 04.PhantomReadSession1.sql


