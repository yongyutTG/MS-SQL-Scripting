# MS SQL Scripting

เรียนรู้การสร้าง Microsoft SQL Server Script และการนำ Script ไปสร้าง Database Objects อาทิ Stored Procedure, Scalar Function, Table-Valued Function และ DML Trigger เป็นต้น และเรียนรู้ภาวะการใช้งานพร้อมกัน และการควบคุมความถูกต้อง 

ใช้ฐานข้อมูลตัวอย่าง [Adventureworks](https://github.com/Microsoft/sql-server-samples/releases/tag/adventureworks)
