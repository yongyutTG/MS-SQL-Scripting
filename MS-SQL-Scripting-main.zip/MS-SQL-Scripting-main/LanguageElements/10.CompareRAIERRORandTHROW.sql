RAISERROR(55055,16,77,'Phakkhaphong')

RAISERROR('Hello %s',16,77,'Phakkhaphong');

THROW 55555,'Hello Kitty!!!',44;
